# MData Azure Deployment Guide

> **Architecture:** Single Node.js App Service (no Azure Functions needed)

---

## Prerequisites

```powershell
winget install Microsoft.AzureCLI
az login
```

---

## Step 1: Create Azure Resources

### Create Resource Group

```powershell
az group create --name mdata-rg --location centralindia
```

### Create App Service Plan (B1 Linux)

```powershell
az appservice plan create --name mdata-plan --resource-group mdata-rg --sku B1 --is-linux
```

### Create Web App (Node.js 20)

```powershell
az webapp create --name mdata-web --resource-group mdata-rg --plan mdata-plan --runtime "NODE:20-lts"
```

---

## Step 2: Configure Environment Variables

Run this single command (replace values with your actual keys):

```powershell
az webapp config appsettings set --name mdata-web --resource-group mdata-rg --settings COSMOS_ENDPOINT="https://mdatadb.documents.azure.com:443/" COSMOS_KEY="31aP5skGDDYTXvJNlklT5a2wCOgjklVQpUElvh1pd8VGFzNIkvM8y8nRf5EtXUs4wpxbaHQZDzcgACDbQqf6Cg" AZURE_STORAGE_CONNECTION_STRING="DefaultEndpointsProtocol=https;AccountName=mdatastorage1;AccountKey=0rCovhHFJKSIlxAGcqaZzM8nS7+3MSuupC+x+hBI8Jjx1Z0/AVrGIQYfWx1/Fhz3i9x8/Nwc8uSN+AStDnmBEg==;EndpointSuffix=core.windows.net" SMTP_USER="pujarirahul.pandu@gmail.com" SMTP_PASS="dxxnyeyiticaosbv" AZURE_OPENAI_ENDPOINT="https://mdata-ai-service.openai.azure.com/" AZURE_OPENAI_KEY="DI6CyuMzpoXyz90QIKzdjIQ2ojoi6WfQuIZeYcYjz1caNyiXd4cSJQQJ99BLACYeBjFXJ3w3AAABACOGLxld" VISION_ENDPOINT="https://mdata-vision.cognitiveservices.azure.com/" VISION_KEY="1X4YWkqsFJ4FkibPx5VvN6VftnUXktqbwVC007UDubGjTmK7TuXpJQQJ99BLACYeBjFXJ3w3AAAFACOGBexr"
```

---

## Step 3: Deploy Code

### Option A: Deploy via Azure CLI (Recommended)

```powershell
cd c:\Projects\MData
az webapp up --name mdata-web --resource-group mdata-rg --runtime "NODE:20-lts"
```

### Option B: Deploy via GitHub Actions

1. Get publish profile:

```powershell
az webapp deployment list-publishing-profiles --name mdata-web --resource-group mdata-rg --xml
```

2. Add output as GitHub secret: `AZURE_WEBAPP_PUBLISH_PROFILE`

3. Push to GitHub:

```powershell
git add . ; git commit -m "Deploy to Azure" ; git push origin main
```

---

## Step 4: Custom Domain Setup

### Add Domain to Azure

```powershell
az webapp config hostname add --webapp-name mdata-web --resource-group mdata-rg --hostname mdata.co.in
```

### DNS Records (Add at your registrar)

| Type  | Name  | Value                        |
| ----- | ----- | ---------------------------- |
| CNAME | www   | mdata-web.azurewebsites.net  |
| A     | @     | (Get IP from Azure Portal)   |
| TXT   | asuid | (Verification ID from Azure) |

### Enable Free SSL Certificate

```powershell
az webapp config ssl create --name mdata-web --resource-group mdata-rg --hostname mdata.co.in
```

### Bind SSL to Domain

```powershell
az webapp config ssl bind --name mdata-web --resource-group mdata-rg --certificate-thumbprint (az webapp config ssl list --resource-group mdata-rg --query "[0].thumbprint" -o tsv) --ssl-type SNI
```

---

## Step 5: Verify Deployment

### Check App Status

```powershell
az webapp show --name mdata-web --resource-group mdata-rg --query "state"
```

### View Live Logs

```powershell
az webapp log tail --name mdata-web --resource-group mdata-rg
```

### Restart App

```powershell
az webapp restart --name mdata-web --resource-group mdata-rg
```

### Open in Browser

```powershell
az webapp browse --name mdata-web --resource-group mdata-rg
```

---

## Estimated Monthly Costs

| Resource     | SKU        | Cost (₹)         |
| ------------ | ---------- | ---------------- |
| App Service  | B1 Linux   | ~1,100           |
| Cosmos DB    | Serverless | ~300-500         |
| Blob Storage | Standard   | ~50-100          |
| OpenAI Usage | Pay-as-go  | ~100-300         |
| **Total**    |            | **~1,500-2,000** |

---

## Quick Reference Commands

| Action  | Command                                                         |
| ------- | --------------------------------------------------------------- |
| Deploy  | `az webapp up --name mdata-web --resource-group mdata-rg`       |
| Restart | `az webapp restart --name mdata-web --resource-group mdata-rg`  |
| Logs    | `az webapp log tail --name mdata-web --resource-group mdata-rg` |
| SSH     | `az webapp ssh --name mdata-web --resource-group mdata-rg`      |
